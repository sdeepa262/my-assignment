export const imageData = [
    { 
        id:'1',
        img: "https://images.unsplash.com/photo-1596182689348-9242f4c265ba?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=426&q=80",
        name: "Brain Lundaquest",
    },
    {
        id:'2',
        img: "https://images.unsplash.com/photo-1596358711484-0b2b0f2344ac?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80",
        name: "Eric MClean",
    },
    {
        id:'3',
        img: "https://images.unsplash.com/photo-1593642634402-b0eb5e2eebc9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name: "Gergia Barbu",
    },
    {
        id:'4',
        img: "https://images.unsplash.com/photo-1596358711710-67d32bfa7f1f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name: "Seba alika",
    },
    {
        id:'5',
        img: "https://images.unsplash.com/photo-1596455596270-5a91ab37752d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"David gutta"
    },
    {
        id:'6',
        img: "https://images.unsplash.com/photo-1596397262763-34013dffe9fa?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Sabrina ket"
    },
    {
        id:'7',
        img: "https://images.unsplash.com/photo-1596418481562-d6fe5ba93645?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Genip tena"
    },
    {
        id:'8',
        img: "https://images.unsplash.com/photo-1596421250711-9ec0ef9cbba3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"suman helin"
    },
    {
        id:'9',
        img: "https://images.unsplash.com/photo-1596474971295-65d4f8963dcf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Quarnt weil"
    },
    {
        id:'10',
        img: "https://images.unsplash.com/photo-1596400416636-9c1a1f7d8c60?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Chiem terr"
    },
    {
        id:'11',
        img:"https://images.unsplash.com/photo-1596529840483-21ed7b5be781?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
        name:"Shingi rice"
    },
    {
        id:'12',
        img:"https://images.unsplash.com/photo-1585825228520-91eb348cf0b4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Huyan via"
    },
     {
        id:'13',
        img:"https://images.unsplash.com/photo-1596552327813-61b50088f69f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Patrick jason"
    },
    {
        id:'14',
        img:"https://images.unsplash.com/photo-1596359958316-90ebcbd4fa06?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Harry cunningham"
    },
    {
        id:'15',
        img:"https://images.unsplash.com/photo-1596451984032-aee3a42eb723?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Nikita sherock"
    },
    {
        id:'16',
        img:"https://images.unsplash.com/photo-1596383112233-8b95bc8a2b65?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Mike Mortogony"
    },
    {
        id:'17',
        img:"https://images.unsplash.com/photo-1596505376251-8874bfff0e63?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Charles etoroma"
    },
    {
        id:'18',
        img:"https://images.unsplash.com/photo-1596546580257-77720f4497dd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Nicolus jecesas"
    },
    {
        id:'19',
        img:"https://images.unsplash.com/photo-1596518696659-b4cb58338da9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Bridget chenn"
    },
    {
        id:'20',
        img:"https://images.unsplash.com/photo-1596385574861-04911815ebd3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Joshuva Fernandise"
    },
    {
        id:'21',
        img:"https://images.unsplash.com/photo-1596503242728-383e318cc030?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
        name:"Insung voon"
    },
];
